# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import traceback
from typing import Any, Dict, Optional

import requests

from utils.util_log.logger import JsonLogger
from utils.util_http.cors import cors_headers, handle_preflight
from utils.util_http.request import parse_event, EventParseError
from utils.util_http.response import ok, bad_request, server_error
from utils.util_errors.exceptions import Internal
from utils.util_errors.to_response import app_error_to_http
from utils.util_sms.sms_sender import validate_phone_number

logger = JsonLogger()

BASE_HEADERS = {
    **cors_headers(allow_origin=os.getenv("CORS_ALLOW_ORIGIN", "*")),
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "Pragma": "no-cache",
    "Expires": "0",
}


def _with_base_headers(resp: Dict[str, Any]) -> Dict[str, Any]:
    headers = resp.get("headers") or {}
    resp["headers"] = {**BASE_HEADERS, **headers}
    return resp


def _require_env(name: str) -> str:
    v = os.getenv(name)
    if not v:
        logger.error("config.env_missing", env=name)
        raise Internal("Service configuration error")
    return v


def _build_message(user_name: Optional[str], comment: Optional[str], email: Optional[str], phone_e164: Optional[str]) -> str:
    parts = ["Оставлена заявка на обратный звонок."]
    if user_name:
        parts.append(f"Имя: {user_name}")
    if comment:
        parts.append(f"Комментарий: {comment}")
    if email:
        parts.append(f"Email: {email}")
    if phone_e164:
        parts.append(f"Телефон: +{phone_e164}")
    return "\n".join(parts)


def _send_sms_to_manager(manager_phone_e164: str, text: str) -> None:
    """Отправляет SMS руководителю через SMSC.ru напрямую (без utils-расширений)."""
    login = os.getenv("SMSC_LOGIN")
    password = os.getenv("SMSC_PASSWORD")
    if not login or not password:
        logger.error("smsc.creds_missing")
        raise RuntimeError("SMSC credentials missing")

    params = {
        "login": login,
        "psw": password,
        "phones": manager_phone_e164,
        "mes": text,
        "fmt": 3,
    }

    try:
        resp = requests.get("https://smsc.ru/sys/send.php", params=params, timeout=10)
        resp.raise_for_status()
        payload = resp.json()
    except (requests.RequestException, ValueError) as e:
        logger.error("smsc.request_error", error=str(e))
        raise RuntimeError("SMSC request error")

    if isinstance(payload, dict) and payload.get("error"):
        logger.error("smsc.api_error", error=payload.get("error"))
        raise RuntimeError("SMSC API error")


def handler(event, context):  # noqa: D401
    logger.info("callback_request.invoked")

    # CORS preflight
    pre = handle_preflight((event or {}).get("headers") or {}, allow_origin=os.getenv("CORS_ALLOW_ORIGIN", "*"))
    if pre:
        return _with_base_headers(pre)

    # Parse request
    try:
        req = parse_event(event)
        body = req.get("body_dict") or {}
    except EventParseError as e:
        logger.warn("callback_request.parse_error", error=str(e))
        return _with_base_headers(bad_request(f"Invalid request: {e}"))

    email = (body.get("email") or "").strip().lower() if body.get("email") else None
    phone_raw = (body.get("phone_number") or "").strip() if body.get("phone_number") else None
    user_name = (body.get("user_name") or "").strip() or None
    comment = (body.get("comment") or "").strip() or None

    phone_e164 = validate_phone_number(phone_raw) if phone_raw else None
    if phone_raw and not phone_e164:
        logger.warn("callback_request.invalid_phone", phone=phone_raw)
        return _with_base_headers(bad_request("Invalid phone number format."))

    if not email and not phone_e164:
        logger.warn("callback_request.missing_identifier")
        return _with_base_headers(bad_request("Either email or phone_number is required."))

    # Compose message
    message_text = _build_message(user_name, comment, email, phone_e164)

    # Resolve manager/operator phone from env and send SMS
    try:
        manager_phone_raw = _require_env("CALLBACK_NOTIFY_PHONE")
        manager_phone = validate_phone_number(manager_phone_raw)
        if not manager_phone:
            logger.error("callback_request.invalid_manager_phone", value=manager_phone_raw)
            return _with_base_headers(server_error("Service configuration error: invalid manager phone"))

        _send_sms_to_manager(manager_phone, message_text)
    except Exception as e:
        logger.error("callback_request.send_failed", error=str(e), trace=traceback.format_exc())
        return _with_base_headers(server_error("Failed to send SMS"))

    logger.info("callback_request.sent", manager_phone=manager_phone, lead_phone=phone_e164, email=email)
    return _with_base_headers(ok({"message": "Callback request sent via SMS."}))